-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 08, 2015 at 11:44 AM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fruit_veg`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_reg`
--

CREATE TABLE IF NOT EXISTS `account_reg` (
  `ac_id` int(11) NOT NULL AUTO_INCREMENT,
  `ac_emp_id` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `ct_id` int(11) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `e_mail` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  PRIMARY KEY (`ac_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `account_reg`
--

INSERT INTO `account_reg` (`ac_id`, `ac_emp_id`, `fname`, `lname`, `username`, `password`, `address`, `c_id`, `s_id`, `ct_id`, `gender`, `contact`, `e_mail`, `dob`) VALUES
(1, 'AC001', 'Nikki', 'Sharma', 'Nikki Sharma', '123', 'Daman', 1, 1, 1, 'female', 1234567890, 'nikki@gmail.com', '1992-01-03'),
(5, 'AC002', '', '', '', '', '', 0, 0, 0, '', 0, '', ''),
(6, 'AC006', '', '', '', '', '', 0, 0, 0, '', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
  `a_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(50) NOT NULL,
  `emp_name` varchar(50) NOT NULL,
  `total_days` int(11) NOT NULL,
  `c_date` varchar(50) NOT NULL,
  `present` int(11) NOT NULL,
  `absent` int(11) NOT NULL,
  `salary_id` int(11) NOT NULL,
  `net_salary` float NOT NULL,
  PRIMARY KEY (`a_id`),
  UNIQUE KEY `emp_id` (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`a_id`, `emp_id`, `emp_name`, `total_days`, `c_date`, `present`, `absent`, `salary_id`, `net_salary`) VALUES
(1, 'AC001', 'Nikki Sharma', 31, '2015-04-01', 4, 27, 20000, 2580.65),
(2, 'HR001', 'Ravi Mistry', 31, '2015-03-31', 3, 28, 25000, 2419.35),
(3, 'PR001', 'p', 31, '2015-04-01', 3, 28, 18000, 1741.94),
(4, 'SL001', 's', 31, '2015-04-01', 3, 28, 30000, 2903.23);

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE IF NOT EXISTS `buy` (
  `buy_id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_no` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` bigint(50) NOT NULL,
  `e_mail` varchar(100) NOT NULL,
  `c_date` varchar(100) NOT NULL,
  `pe_id` int(11) NOT NULL,
  `b_quantity` int(11) NOT NULL,
  `b_price` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`buy_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`buy_id`, `bill_no`, `name`, `address`, `contact`, `e_mail`, `c_date`, `pe_id`, `b_quantity`, `b_price`, `status`) VALUES
(1, '1', 'c', 'kothrud', 5012346987, 'cccccc@gmail.com', '2015-Mar-30', 1, 1, 500, 'paid'),
(2, '1', 'c', 'kothrud', 5012346987, 'cccccc@gmail.com', '2015-Mar-30', 2, 3, 600, 'paid'),
(3, '2', 'pooja', 'daman', 7894561231, 'pooja_sharma@gmail.com', '2015-Mar-31', 1, 2, 500, 'paid'),
(4, '3', 'pooja', 'daman', 7894561231, 'pooja_sharma@gmail.com', '2015-Mar-30', 1, 2, 500, 'paid'),
(5, '3', 'pooja', 'daman', 7894561231, 'pooja_sharma@gmail.com', '2015-Mar-30', 3, 2, 400, 'paid'),
(6, '4', 'c', 'warje', 1236549870, 'ssssssss@gmail.com', '2015-Mar-30', 3, 2, 400, 'paid'),
(7, '4', 'c', 'warje', 1236549870, 'ssssssss@gmail.com', '2015-Mar-30', 1, 1, 500, 'paid'),
(8, '5', 'c', 'sasasasasasa', 8282828282, 'sasasasa@yahoo.com', '2015-Mar-31', 1, 1, 500, 'Unpaid'),
(9, '5', 'c', 'sasasasasasa', 8282828282, 'sasasasa@yahoo.com', '2015-Mar-31', 5, 1, 600, 'Unpaid'),
(10, '6', 'c', 'aadadad', 1313113131, 'dadaaaddad', '2015-Mar-31', 2, 2, 600, 'Unpaid'),
(11, '7', 'c', 'qwqwqw', 4949494994, 'wqwqwqwqw', '2015-Mar-31', 5, 4, 600, 'Unpaid'),
(12, '8', 'c', 'dasdasdasd', 233432432, 'dasdasdasd', '2015-Mar-31', 4, 5, 495, 'paid'),
(15, '9', 'Raj', 'Kolhapur', 9801020304, 'raj@gmail.com', '2015-Apr-07', 2, 2, 132, 'Unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `ct_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_id` int(11) NOT NULL,
  `city` varchar(50) NOT NULL,
  PRIMARY KEY (`ct_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`ct_id`, `s_id`, `city`) VALUES
(1, 1, 'Surat'),
(2, 2, 'Dubai'),
(3, 3, 'Pune'),
(4, 4, 'United');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(50) NOT NULL,
  PRIMARY KEY (`c_id`),
  UNIQUE KEY `country` (`country`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`c_id`, `country`) VALUES
(1, 'India'),
(2, 'UAE');

-- --------------------------------------------------------

--
-- Table structure for table `customer_reg`
--

CREATE TABLE IF NOT EXISTS `customer_reg` (
  `cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `ct_id` int(11) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `e_mail` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `customer_reg`
--

INSERT INTO `customer_reg` (`cust_id`, `fname`, `lname`, `username`, `password`, `address`, `c_id`, `s_id`, `ct_id`, `gender`, `contact`, `e_mail`, `dob`) VALUES
(1, 'c', 'c', 'c', '123', 'surat', 2, 2, 2, 'male', 5012346987, 'ccccccc@gmail.com', '1992-07-16'),
(3, 'sonal', 'patil', 'patil', 'sonal', 'pune', 1, 1, 1, 'female', 9604052315, 'shree@gmail.com', '2015-04-08'),
(30, 'Raj', 'Joshi', 'Raj', '123', 'Kolhapur', 1, 3, 3, 'male', 9801020304, 'raj@gmail.com', '2004-08-05');

-- --------------------------------------------------------

--
-- Table structure for table `fo_reg`
--

CREATE TABLE IF NOT EXISTS `fo_reg` (
  `fo_id` int(11) NOT NULL AUTO_INCREMENT,
  `fo_emp_id` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `ct_id` int(11) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `e_mail` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  PRIMARY KEY (`fo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `fo_reg`
--

INSERT INTO `fo_reg` (`fo_id`, `fo_emp_id`, `fname`, `lname`, `username`, `password`, `address`, `c_id`, `s_id`, `ct_id`, `gender`, `contact`, `e_mail`, `dob`) VALUES
(1, '', 'm', 'm', 'm', 'm', 'Pune', 1, 3, 3, 'female', 9604052315, 'shree@gmail.com', '1992-09-05');

-- --------------------------------------------------------

--
-- Table structure for table `hr_reg`
--

CREATE TABLE IF NOT EXISTS `hr_reg` (
  `hr_id` int(11) NOT NULL AUTO_INCREMENT,
  `hr_emp_id` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `ct_id` int(11) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `e_mail` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  PRIMARY KEY (`hr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `hr_reg`
--

INSERT INTO `hr_reg` (`hr_id`, `hr_emp_id`, `fname`, `lname`, `username`, `password`, `address`, `c_id`, `s_id`, `ct_id`, `gender`, `contact`, `e_mail`, `dob`) VALUES
(1, 'HR001', 'Ravi', 'Mistry', 'Ravi Mistry', '123', 'Bardoli', 1, 1, 1, 'male', 1023456789, 'ravi@gmail.com', '1889-05-19');

-- --------------------------------------------------------

--
-- Table structure for table `pak_entry`
--

CREATE TABLE IF NOT EXISTS `pak_entry` (
  `pak_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `sp_id` int(11) NOT NULL,
  `image_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`pak_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pak_entry`
--


-- --------------------------------------------------------

--
-- Table structure for table `pak_reg`
--

CREATE TABLE IF NOT EXISTS `pak_reg` (
  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
  `pk_emp_id` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `ct_id` int(11) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `e_mail` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pak_reg`
--

INSERT INTO `pak_reg` (`pk_id`, `pk_emp_id`, `fname`, `lname`, `username`, `password`, `address`, `c_id`, `s_id`, `ct_id`, `gender`, `contact`, `e_mail`, `dob`) VALUES
(1, 'PK001', 'Ganesh', 'Naik', 'Shree', '123', 'Pune', 1, 1, 3, 'male', 9604052315, 'shree@gmail.com', '1990-09-05');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `product` varchar(50) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `product`) VALUES
(1, 'Fruits'),
(2, 'Vegetable');

-- --------------------------------------------------------

--
-- Table structure for table `product_entry`
--

CREATE TABLE IF NOT EXISTS `product_entry` (
  `pe_id` int(11) NOT NULL AUTO_INCREMENT,
  `saller` varchar(50) NOT NULL,
  `p_id` int(11) NOT NULL,
  `sp_id` int(11) NOT NULL,
  `image_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `sale_price` bigint(20) NOT NULL,
  `total_price` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`pe_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `product_entry`
--

INSERT INTO `product_entry` (`pe_id`, `saller`, `p_id`, `sp_id`, `image_name`, `quantity`, `price`, `sale_price`, `total_price`, `date`) VALUES
(1, 'Mrunal', 1, 1, '../../FRUIT_VEG/Photos/201207270954PackagingApples.jpg', 98, 80, 88, 8000, '2015-04-07'),
(2, 'Sayali', 1, 3, '../../FRUIT_VEG/Photos/healthy-fruit-and-vegetables.jpg', 98, 120, 132, 12000, '2015-04-07'),
(3, 'Piyush', 2, 2, '../../FRUIT_VEG/Photos/mini gamme barquette.jpg', 50, 60, 66, 3000, '2015-04-07'),
(4, 'Yash', 1, 3, '../../FRUIT_VEG/Photos/All.jpg', 198, 120, 132, 24000, '2015-04-07'),
(5, 'Srushti', 1, 1, '../../FRUIT_VEG/Photos/aardvaark.jpg', 75, 80, 88, 6000, '2015-04-07');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_reg`
--

CREATE TABLE IF NOT EXISTS `purchase_reg` (
  `pr_id` int(11) NOT NULL AUTO_INCREMENT,
  `pr_emp_id` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `ct_id` int(11) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `e_mail` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  PRIMARY KEY (`pr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `purchase_reg`
--

INSERT INTO `purchase_reg` (`pr_id`, `pr_emp_id`, `fname`, `lname`, `username`, `password`, `address`, `c_id`, `s_id`, `ct_id`, `gender`, `contact`, `e_mail`, `dob`) VALUES
(1, 'PR001', 'p', 'p', 'p', '123', 'pune', 2, 2, 2, 'male', 1030456789, 'ppppp@gmail.com', '1991-08-22'),
(2, 'PR002', 'rahul', 'mistry', 'rahul', 'rahul', 'pune', 1, 3, 3, 'male', 8980891822, 'rahulmistry@gmail.com', '1990-05-08'),
(3, 'PR003', 'Mrunal', 'Chougule', 'Mrunal', '123', 'Hasur', 1, 3, 3, 'female', 9801020304, 'chougule.mrunal@gmail.com', '1991-09-05');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE IF NOT EXISTS `salary` (
  `salary_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(50) NOT NULL,
  `emp_name` varchar(50) NOT NULL,
  `salary` double NOT NULL,
  PRIMARY KEY (`salary_id`),
  UNIQUE KEY `emp_id` (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`salary_id`, `emp_id`, `emp_name`, `salary`) VALUES
(1, 'AC001', 'Nikki Sharma', 20000),
(2, 'HR001', 'Ravi Mistry', 25000),
(3, 'PR001', 'p', 18000),
(4, 'SL001', 's', 30000),
(5, 'PR002', 'rahul', 55000),
(6, 'SL002', 'shikha', 80000);

-- --------------------------------------------------------

--
-- Table structure for table `sales_reg`
--

CREATE TABLE IF NOT EXISTS `sales_reg` (
  `sl_id` int(11) NOT NULL AUTO_INCREMENT,
  `sl_emp_id` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `ct_id` int(11) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `e_mail` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  PRIMARY KEY (`sl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sales_reg`
--

INSERT INTO `sales_reg` (`sl_id`, `sl_emp_id`, `fname`, `lname`, `username`, `password`, `address`, `c_id`, `s_id`, `ct_id`, `gender`, `contact`, `e_mail`, `dob`) VALUES
(1, 'SL001', 's', 's', 's', '123', 'pune', 2, 4, 4, 'female', 4012356789, 'sssss@yahoo.com', '1990-06-28'),
(2, 'SL002', 'shikha', 'bajpai', 'shikha', 'shikha', 'mumbai', 1, 3, 3, 'female', 9684625389, 'shikha.bajpai@gmail.com', '1993-06-05');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` int(11) NOT NULL,
  `state` varchar(50) NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`s_id`, `c_id`, `state`) VALUES
(1, 1, 'Gujarat'),
(2, 2, 'UAE State1'),
(3, 1, 'Maharastra'),
(4, 2, 'UAE State2');

-- --------------------------------------------------------

--
-- Table structure for table `sub_product`
--

CREATE TABLE IF NOT EXISTS `sub_product` (
  `sp_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `sub_product` varchar(50) NOT NULL,
  PRIMARY KEY (`sp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `sub_product`
--

INSERT INTO `sub_product` (`sp_id`, `p_id`, `sub_product`) VALUES
(1, 1, 'Apple'),
(2, 2, 'Drumsticks'),
(3, 1, 'Fig'),
(4, 2, 'Cauliflower'),
(5, 2, 'Brinjal');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
